clear;
clc;
%testMur = Mur([0 3.5 12.5],[-1 0 0],0,7,15,true,0);
%testMur.GetMeshGrid(0.1)

Devoir4([-10,-10,15],1,1);
%Devoir4([13,10,25],1,1.5);
%Devoir4([-10,-10,15],1.33,1.1);
%Devoir4([13,10,25],1.33,1.1);