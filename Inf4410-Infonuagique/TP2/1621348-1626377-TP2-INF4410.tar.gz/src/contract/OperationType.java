package contract;

public enum OperationType implements java.io.Serializable{
	Pell,
	Prime
}
