package contract;

public enum ResultStatus implements java.io.Serializable{
	Success,
	// Si workload trop eleve
	Deny
}
